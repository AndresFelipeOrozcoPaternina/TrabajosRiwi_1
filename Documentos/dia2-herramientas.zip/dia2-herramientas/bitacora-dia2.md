# Bitácora · Día 2 · Herramientas de desarrollo

- **Coder: Andres Felipe Orozco Paternina**
- **Fecha: 16/10/2026**
- **TL: Johan Alexander Rivera Vasquez**

---

## 1. Mi entorno de desarrollo (Etapa 1)

- Versión de Ubuntu:
- Versión de Python:
- ¿Dónde está instalado Python? (resultado de `which python3`):
  R// Python esta instalado en /usr/bin/python3
- Con mis palabras, la diferencia entre un compilador y un intérprete es:
  R// EL interprete traduce linea por linea el codigo, el copilador traduce todo y despues lo manda en otro lenguaje
- ¿Qué pasó con la línea 4 de `hola.py` y por qué?:
   R// No se ejecuto porque en la linea 3 busca una variable con ese nombre, pero en este caso no hay ninguna entonces saca el error y no pasa la linea 4
| Herramienta | ¿Qué es? (sistema operativo, editor, intérprete, compilador o navegador) |
|---|---|
| Ubuntu | Sistema Operativo |
| VS Code | Editor |
| Python | Interprete |
| Chrome | Navegador |
| gcc | Copilador |

## 2. Reinstalación de VS Code (Etapa 2)

- ¿Cómo estaba instalado VS Code? (snap, .deb o no estaba):
   R// Se instalo por paquete .deb
- Comando que usé para desinstalarlo: 
   R// sudo apt remove code
- Comando que usé para instalarlo:
   R// sudo apt install ./code_*.deb
- ¿Por qué es importante instalar desde la fuente oficial?:
   R// Para evitar estilar apk con virus u otras cosas
- ¿Qué pasó con mi configuración al desinstalar? ¿Dónde vive?:
   R// Siguen mis datos iguales, se encuentran aca ls ~/.config/Code

## 3. Perfiles y extensiones (Etapa 3)

- Con mis palabras, un perfil de VS Code es:
- ¿Qué cambia en el Explorador entre un perfil y otro?:
  R// Cambia las extensiones que se instala, ya que cada perfil tiene las suyas y no se pasan
- ¿Por qué VS Code pregunta si confío en el publicador de una extensión?:
  R// Para evitar descargar una extensiones no verificadas y no instalar un virus 

## 4. Duelo de perfiles (Etapa 4)

| Prueba | Perfil2-Basico | Perfil1-Pro |
|---|---|---|
| 1. Auto guardado | NO se guarda automatico ya que no hicimos el proceso (Se necesita poner ctrl+s)| Aplica el autoguardo y no hay necesidad de poner ctrl + s |
| 2. Auto Rename Tag |  Si no esta la extension, debes cambiar la etiqueta | Cambia la etiqueta de cierre en tiempo real |
| 3. Error Lens |  Los errores solo se ven con un subrayado ondulado rojo | Muestra el texto del error y resalta toda la linea con color  |
| 4. Íconos | Muestra los propios iconos del visual| Asigna diferentes simbolos dependiendo del dato|
| 5. Guías de indentación | Tiene los colores estanda| Muestra las cosas en diferentes colores para poder guiarse|
| 6. Extensiones corriendo | No se guarda ninguna, se queda la misma estructura del propio visual | Se guardan todas las extensiones descargadas|

**Reflexión**

1. ¿Noté diferencias en la experiencia de trabajo entre los dos perfiles? ¿Cuáles?
    R// mayormente la interfaz de estos que ayuda a guiarse en el codigo
   -
2. ¿Qué ventajas tiene usar múltiples perfiles en VS Code?
   R// poder descargar extensiones sin afectar a los demas
   -
3. ¿Cómo influyen las extensiones en la productividad y en el rendimiento del editor?
   -R// mucho ya que si tienes demasiadas extensiones puede empeorar el fluijo de este
4. ¿Cuándo sería útil usar perfiles distintos en un entorno profesional? (dos ejemplos)
   -R// Cuandohay gente utilizando un mismo equipo
        Cuando quieres cambiar de extensiones segun la necesidad

## 5. Inspección y modificación (Etapa 5)

- Página que usé:
- Cinco etiquetas que encontré y para qué sirven:
  1.<span> : Esta sirve para poner mensajes cortos
  2.<p>: Para poner un parafo 
  3.<main>: la estructura principal de la pagina
  4.<section>: Lo que esta adentro es un apartado de un codigo
  5.<body>: Es todoel cuerpo del html
- ¿Qué pasó con mis cambios al recargar y por qué?:
   Porque lo que cambie fue la pagina en mi navegador, no el frontend de este
- Con mis palabras, el DOM es:

## 6. La consola (Etapa 6)

| Operación | Mi predicción | Resultado real |
|---|---|---|
| `2 + 3` | 5 | 5 |
| `10 - 4 * 2` | 2 | 2|
| `(10 - 4) * 2` | 12 | 12 |
| `10 / 4` | 2.5 | 2.5 |
| `10 % 3` |1 | 1 |
| `2 ** 8` | 256 | 256 |
| `120000 * 0.19` | 22800 | 22800 |
| `365 * 24` | 8760 | 8760 |

- ¿Por qué `0.1 + 0.2` no da exactamente `0.3`?:
- Errores o advertencias que encontré en la página (o "ninguno"):
   R// Ninguno
- Diferencia entre un error y una advertencia:
  R// El error hace que el codigo no funcione, la advertencia es un recomendacion
## 7. La red / Network (Etapa 7)

| Imagen | Formato | Tamaño | Tiempo | Código de estado |
|---|---|---|---|---|
| Hero_apple_card | jpeg | 63.4 kb |53 ms | 200 |
| Hero_iphone_duo | jpeg | 41.5kb | 47 ms| 200 |
| Hero_iphone_18| jpeg | 14.3 kb | 95 ms | 200 |

| Experimento | Solicitudes | Transferido | Load |
|---|---|---|---|
| A. Sin caché | 10 | 116 kb | 706 ms |
| B. Con caché | 10 | 0.6 kb | 395 ms |
| C. Red lenta | 10 | 0.6 kb | 13.12s |

- Archivo más pesado de la página y su tipo:
   R// Es una imagen jpeg y pesa 23.9 kb 
- ¿Por qué la página cargó más rápido con caché?:
   R// El navegador guarda una copia de este
- ¿Por qué un desarrollador querría probar con una red lenta?:
   R// Para garantizar la experiencia sin importar la conexion de red
- ¿Qué haría para que una imagen pesada cargue más rápido?:
   R// Una mayor cantidad en la conexion de red

## 8. Dispositivos móviles (Etapa 8)

| Ancho (px) | Dispositivo | ¿Cambia el menú? | ¿Imágenes bien? | ¿Scroll horizontal? | Observación |
|---|---|---|---|---|---|
| 320 | Movil | si, por uno desplegable | si, estan bien | Tambien tiene | por el cambio de tamaño afecta la interfaz |
| 375 | Iphone SE | si, por uno desplegable | si, estan bien  | tambien tiene | por el cambio de tamaño afecta la interfaz |
| 768 | Ipad Mini | si, por uno desplegable | si, esta bien | tambien tiene |  por el cambio de tamaño afecta la interfaz, pero se ve mas grande|
| 1024 | Ipad pro 13 | si, ya se ve en la parte de arriba | Se ven mas grandes | si tiene | ya por el tamaño se ve un menu arriba |
| 1440 | Nest hub max| si, ya se ve en la parte de arriba  | Se ven mas grandes | no tiene| por ser un televisor dolo tiene un modo|

- ¿Por qué es importante probar varias resoluciones antes de entregar un proyecto?:

## 9. Laboratorio de errores (Etapa 9)

| # | Tipo | ¿Dónde lo detecté? | Mensaje o síntoma | Causa | Solución aplicada |
|---|---|---|---|---|---|
| 1 | CSS / Ruta | Network / public/index.html (Linea 7) | La pagina se ve sin colores ni estilos  | La ruta en el HTML es ../css/styles.css, pero la carpeta real se llama CSS | Cambiar la ruta a ../CSS/styles.css |
| 2 | Bug / JS | Console / JS/app.js (Linea 11) | TypeError: Cannot read properties of null (reading 'addEventListener') | El JS busca el id #btn-saludar, pero en el HTML el boton tiene id="boton-saludar" | Cambiar en JS a document.querySelector"#boton-saludar"|
| 3| Bug / JS | Console / JS/app.js (Línea 14) | Uncaught ReferenceError: nombreCodr is not defined (al hacer clic en Saludar) | Se uso nombreCodr  en lugar de nombreCoder  | Corregir el nombre de la variable a nombreCoder dentro del click |
| 4 | Recursos / Imagen | Network / public/index.html (Línea 15) | El logo no carga / imagen rota en el encabezado | El archivo logo.png esta vacio  | Copiar una imagen valida a la ruta del logo |

- Uno de los errores, descrito con detalle, y cómo lo resolví:
  el error del direccionamineto del css, lo resulvi ya que a iniciar el proyecto en la terminal aparecia 404
- ¿Qué vi al pausar con el breakpoint?:
  Vi que la ejecucion de la pagina se congelo justo en la linea donde saludaba y al pasar el mouse por encima de las variables pude ver que nombreCoder tenia guardado el texto "Coder de Riwi" mientras que nombreCodr salia como undefined porque estaba mal escrita.
- ¿Qué pasó al cambiar `visitas` por 99 y al borrarlo?:
  Al cambiar el valor a 99 y recargar la pagina el contador mostro 100 porque el script le sumo 1 al valor que puse guardado. Al borrar la clave y recargar la pagina el contador se reinicio desde 1 porque el codigo no encontro nada guardado y empezo de cero
- ¿Para qué usan el localStorage las páginas reales? ¿Qué NO debería guardar ahí?:
 Las paginas reales lo usan para guardar cosas sencillas que no son secretas como el tema oscuro o claro el carrito de compras o las preferencias del usuario. Nunca se deben guardar contraseñas datos bancarios tokens de sesion ni informacion personal sensible porque cualquier persona o script puede verlos y cambiarlos facilmente
- Ancho exacto en el que se apilan las tarjetas y regla de CSS responsable:
 Se apilan exactamente a los 600px de ancho y la regla responsable es @media (max-width: 600px) que cambia el .contenido a flex-direction: column
- ¿Por qué no basta con mirar solo la consola para encontrar errores?:
 No basta porque hay errores silenciosos que la consola no detecta como rutas mal puestas de imágenes archivos de CSS
## 10. Comparación con Firefox (Etapa 10)

| Herramienta | Chrome: nombre y atajo | Firefox: nombre y atajo | Diferencia que noté |
|---|---|---|---|
| Inspeccionar HTML y CSS | | | |
| Consola | | | |
| Red | | | |
| Simulación de dispositivos | | | |
| Almacenamiento local | | | |
| Mensaje del error que reintroduje | | | |

- Una característica de Firefox interesante o diferente a Chrome (qué es, para qué sirve y cómo la probé):

## 11. Reflexión final (Etapa 11)

- La herramienta que más voy a usar y por qué:
 La herramienta sera DevTools en si, es una herramienta que ayuda demasiado para desarrollar paginas
- Lo más difícil del día y cómo lo resolví:
  La mas dificil fue el de "boton-saludar", la resolvi porque un compañero me ayudo a encontrarla
- Las DevTools explicadas para alguien que no programa (3 líneas):
Es un apartado donde puedes ver el frontend de la pagina que estas viendo, donde podras ver lo que compone en ella y poder hacer varios cambios para ver como funciona.